#include <iostream>

class Person {
private:
    std::string FirstName;
    std::string LastName;
    char sex;

public:
    Person(){}
    Person(std::string fname, std::string lname, char s) {
        FirstName = fname;
        LastName = lname;
        sex = s;
    }

    std::string getFirstName() {
        return FirstName;
    }

    std::string getLastName() {
        return LastName;
    }

    char getSex(){
        return sex;
    }
    
    void setFirstName(std::string fname) {
        FirstName = fname;
    }

    void setLastName(std::string lname) {
        LastName = lname;
    }

    void setSex(char s){
       s = toupper(s);
        if(s == 'M' || s == 'F'){
            sex = s;
        }
        else
            sex = 'X'; //Invalid Input 
    }

};
